package com.seed;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//	TODO:1 Make DisplayCartDetailsServlet as a HttpServlet

public class DisplayCartDetailsServlet extends HttpServlet{

//	TODO:2 	Provide call-back method (called by web container) for HTTP request made using HTTP GET method
//	TODO:3	This method should read products selected by web-client from bookCatelogue.html and 
//					display them in tabular format as html response to the web client.	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		PrintWriter out = response.getWriter();
		String checkboxvalue = request.getParameter("bookName");
		
		
		out.println("<HTML>");
		out.println("<head>");
		out.println("<title>");
		out.println("my first lab program");
		out.println("</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<table border = \1\">");
		out.println("<tr>");
		out.println("<td>"); out.println("your selected value"); out.println("</td>");
		out.println("<td>"); out.println(checkboxvalue); out.println("</td>");
		out.println("</tr>");
		out.println("</body>");
		out.println("</html>");
		
	}
}