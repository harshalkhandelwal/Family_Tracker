package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Account;
import com.capgemini.beans.Options;
import com.capgemini.dao.AccountDAOImpl;
import com.capgemini.dao.AccountDAo;

public class AccountServiceImpl implements AccountService{
	
	private AccountDAo daoRef = new AccountDAOImpl();

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		
		List<Account> accounts = daoRef.findAll();
		return accounts;
	}

	@Override
	public List<Account> sortAccountDetails(Options option) {
		// TODO Auto-generated method stub
		return daoRef.sortAccountDetails(option);
	}

	@Override
	public boolean create(Account newAccount) {
		// TODO Auto-generated method stub
		return daoRef.create(newAccount);
	}

	@Override
	public boolean delete(int id) {
		return daoRef.delete(id);
	}

	@Override
	public boolean update(int id, Account account) {
		return daoRef.update(id, account);
		
	}

	@Override
	public Account findById(int id) {
		// TODO Auto-generated method stub
		return daoRef.findById(id);
	}

}
