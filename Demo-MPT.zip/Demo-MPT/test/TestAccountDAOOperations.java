import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Account;
import com.capgemini.dao.AccountDAOImpl;
import com.capgemini.dao.AccountDAo;

public class TestAccountDAOOperations {
	
	private AccountDAo daoRef;
	
	@Before
	public void setup()
	{
		System.out.println("setting up dao object");
		System.out.println("-----------------------");
		daoRef = new AccountDAOImpl();
	}

	@Test
	public void test1() {
		//fail("Not yet implemented");
	}
	
	@Test
	public void test2()
	{
		Account account = new Account();
		account.setId(15);
		account.setBalance(1500);
		account.setName("harshal");
		
		boolean flag = daoRef.create(account);
		
		assertTrue(flag);
		
		account = new Account();
		account.setId(4);
		account.setBalance(1500);
		account.setName("harshal");
		
		flag = daoRef.create(account);
		
		assertFalse(flag);
	}
	
	@Test
	public void test3()
	{
		boolean flag = daoRef.delete(4);
		assertTrue(flag);
	}
	
	@Test
	public void test4()
	{
		Account ac  = daoRef.findById(2);
		boolean flag=true;
		if(ac==null)
		{
			flag=false;
		}
		else
		{
			flag=true;
		}
		assertTrue(flag);
	}
	
	@Test
	public void test5()
	{
		List<Account> acc = daoRef.findAll();
		boolean flag = acc.isEmpty();
		assertFalse(flag);
	}
	
	@After
	public void tearDown()
	{
		System.out.println("cleaning up dao object");
		System.out.println("-----------------------");
		daoRef=null;
		
	}

}
