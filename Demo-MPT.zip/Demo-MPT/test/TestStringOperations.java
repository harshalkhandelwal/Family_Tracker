import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class TestStringOperations {

	@Test
	public void test() {
		//fail("Not yet implemented");
		
		String expectedmsg = "Hello world!";
		String actualmsg = new String("Hello world!");
		
		
		//actualmsg=null;
		assertTrue(actualmsg.length()>0);
		
		assertEquals(expectedmsg, actualmsg);
		
		assertNotSame(expectedmsg, actualmsg);
		
	}

}
