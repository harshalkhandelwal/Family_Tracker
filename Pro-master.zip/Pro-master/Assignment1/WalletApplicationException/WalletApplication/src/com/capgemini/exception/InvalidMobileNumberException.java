package com.capgemini.exception;

public class InvalidMobileNumberException extends Exception {

}
