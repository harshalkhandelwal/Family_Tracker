
public class InsufficientAccountBalanceOpeningException extends Exception {

}
