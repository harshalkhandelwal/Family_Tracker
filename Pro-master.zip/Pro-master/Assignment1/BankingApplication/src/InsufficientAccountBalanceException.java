
public class InsufficientAccountBalanceException extends Exception{

}
