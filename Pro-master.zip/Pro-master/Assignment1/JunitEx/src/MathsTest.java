import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MathsTest {
	Maths obj=new Maths();
	@Test
	public void Test()
	{
		assertEquals(8,obj.addition(4, 4));
	}


	void test() {
		fail("Not yet implemented");
	}

}
