
public class Maths 
{
	public int addition(int a, int b) {
		return a+b;
	}

}
