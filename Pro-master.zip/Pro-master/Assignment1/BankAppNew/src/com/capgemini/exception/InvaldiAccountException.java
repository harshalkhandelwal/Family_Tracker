package com.capgemini.exception;

public class InvaldiAccountException extends Exception {

}
