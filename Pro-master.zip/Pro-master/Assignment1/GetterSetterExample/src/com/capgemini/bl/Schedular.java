package com.capgemini.bl;

public class Schedular {

}
