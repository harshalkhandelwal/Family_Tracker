package com.capg.xyzwallet.bean;



public class PrintTransaction {

}
